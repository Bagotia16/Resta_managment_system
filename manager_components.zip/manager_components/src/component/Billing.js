import React, { useState } from "react";
import TextField from "@material-ui/core/TextField";

const Billing = () => {
const [name, setName] = useState("");

return (
	<div
	style={{
		marginTop: "10%",
	}}
	>
	<h2><u>BILLING</u></h2>

    <form>
      <label>ORDER ID_______:   
        <input type="text" />
      </label>
    </form>

    <form>
      <label>CUSTOMER ID___:  
        <input type="text" />
      </label>
    </form>

    <form>
      <label>AMOUNT________:
        <input type="text" />
      </label>
    </form>


	</div>
);
};

export default Billing;
