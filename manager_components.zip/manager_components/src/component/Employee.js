import React, { useState } from "react";
import TextField from "@material-ui/core/TextField";

const Employee = () => {
const [name, setName] = useState("");

return (
	<div
	style={{
		marginTop: "10%",
	}}
	>
	<h2><u>EMPLOYEE</u></h2>

    <form>
      <label>CASHIER INFO__:   
        <input type="text" />
      </label>
    </form>

    <form>
      <label>WAITER________:  
        <input type="text" />
      </label>
    </form>

    <form>
      <label>CHEF___________:
        <input type="text" />
      </label>
    </form>


	</div>
);
};

export default Employee;
