import React, { useState } from "react";

const Table = () => {
const [name, setName] = useState("");

return (
	<div
	style={{
		marginTop: "10%",
	}}
	>
	<h2><u>TABLE</u></h2>
    <h3>.............<b>ALL TABLE INFO OF THE RESTRAUNT</b>................</h3>
	</div>
);
};

export default Table;
