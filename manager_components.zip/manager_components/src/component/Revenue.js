import React, { useState } from "react";
import TextField from "@material-ui/core/TextField";

const Revenue = () => {
const [name, setName] = useState("");

return (
	<div
	style={{
		marginTop: "10%",
	}}
	>
	<h2><u>REVENUE</u></h2>
    <h3>........ALL REVENUE INFO OF THE RESTRAUNT........</h3>

	</div>
);
};

export default Revenue;
