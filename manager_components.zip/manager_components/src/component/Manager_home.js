import React from "react";
// import ParticlesBg from "particles-bg";
import {Link} from "react-router-dom";
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import { rgbToHex } from "@mui/material";

function Home(){
    return(
        <section style={{ backgroundImage:`url(https://media.istockphoto.com/photos/waitress-at-a-restaurant-getting-a-delivery-order-on-the-phone-and-a-picture-id1256186622?k=20&m=1256186622&s=612x612&w=0&h=BBt6cHgbVZGob5knjRH9xwwwipSiJAbcFyj8eOxyNYI=)`,backgroundRepeat:"no-repeat",backgroundSize:"cover",backgroundPosition: "center", height: 870}}>
            <h1 ></h1>
            <h1> MANAGER</h1>
            <div>
                {/* <Box component='div' sx = {{background : '#5f8eb2'}}> */}
                    <Box component="span" sx = {{p : 2, border: '1px', borderRadius: '5px', display: 'inline-block', margin: '5px'}}>
                        <Link to='/employee' underline="none" style = {{textDecoration: "None"}}><Button variant="contained" color="success">Employee</Button></Link>
                    </Box>
                    <Box component="span" sx = {{p : 2, border: '1px', borderRadius: '5px', display: 'inline-block', margin: '5px'}}>
                        <Link to='/billing' underline="none" style = {{textDecoration: "None"}}><Button variant="contained" color="success">Billing</Button></Link>
                    </Box>
                    <Box component="span" sx = {{p : 2, border: '1px', borderRadius: '5px', display: 'inline-block', margin: '5px'}}>
                        <Link to='/table' underline="none" style = {{textDecoration: "None"}}><Button variant="contained" color="success">Table</Button></Link>
                    </Box>
                    <Box component="span" sx = {{p : 2, border: '1px', borderRadius: '5px', display: 'inline-block', margin: '5px'}}>
                        <Link to='/revenue' underline="none" style = {{textDecoration: "None"}}><Button variant="contained" color="success">Revenue</Button></Link>
                    </Box>
                    <Box component="span" sx = {{p : 2, border: '1px', borderRadius: '5px', display: 'inline-block', margin: '5px'}}>
                        <Link to='/ingredients' underline="none" style = {{textDecoration: "None"}}><Button variant="contained" color="success">Ingredients</Button></Link>
                        
                    {/* </Box> */}
                </Box>
            </div>
        </section>
    );
}

export default Home;