import React, { useState } from "react";
import TextField from "@material-ui/core/TextField";

const Ingredients = () => {
const [name, setName] = useState("");

return (
	<div
	style={{
		marginTop: "10%",
	}}
	>
	<h2><u>INGREDIENTS</u></h2>

    <form>
      <label>INGREDIENTS ID_______:   
        <input type="text" />
      </label>
    </form>

    <form>
      <label>INGREDIENTS NAME___:  
        <input type="text" />
      </label>
    </form>

    <form>
      <label>QUANTITY____________:
        <input type="text" />
      </label>
    </form>


	</div>
);
};

export default Ingredients;
