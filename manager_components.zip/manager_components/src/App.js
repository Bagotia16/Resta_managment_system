import './App.css';
import React from 'react';
import Manager_home from './component/Manager_home';
import Billing from './component/Billing';
import Employee from './component/Employee';
import Revenue from './component/Revenue';
import Table from './component/Table';
import Ingredients from './component/Ingredients';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        {/* <Nav /> */}
          <Routes>
            <Route path="/" element = {<Manager_home/>} />
            <Route path="/billing" element = {<Billing/>} />
            <Route path="/employee" element = {<Employee/>} />
            <Route path="/revenue" element = {<Revenue/>} />
            <Route path="/table" element = {<Table/>} />
            <Route path="/ingredients" element = {<Ingredients/>} />
          </Routes>
      </div>
    </Router>
  );
}

export default App;
